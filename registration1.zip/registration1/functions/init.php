<?php
ob_start();
session_start();
include "db.php";
include "ajax.php";
include "functions.php";
