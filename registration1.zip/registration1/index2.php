<?php
include('inc/header.php');
?>
	<div class="jumbotron">
		<h1 class="text-center">Registration Success !</h1>
	</div>
<?php
?>